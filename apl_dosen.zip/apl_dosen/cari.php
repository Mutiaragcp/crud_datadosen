<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Aplikasi Data Siswa Kelas XI RPL </title>
</head>
<body>
    <h3>Form Pencarian Data pacar muti<br>
         </h3>
        <p>
            Berikut ini form pencarian data siswa, silahkan masukan kata kunci pada form dibawah ini
        </p>
        <p>
            <a href="index.php" class="btn btn-dark text-info m-2">Show Data</a>
        </p>
        <form action="" method="POST">
            <p>
            &nbsp;Kata Kunci<br>
                <input type="text" name="txtKataKunci" class="form-control" placeholder="Masukan Kata Kunci (NIS/Nama/Alamat/Nomor WhatsApp)" size="40" required autofocus>
            </p>

            <p>
                <button name="cari" type="submit" class="btn btn-dark text-info m-2">Search</button>
            </p>
        </form>
        <?php
            if(isset($_POST['cari'])){
                $htmlTable='<table border="1" width="100%" align="center" class="table table-bordered table-hover">
                    <thead class="bg-dark text-center text-info">
                        <tr>
                            <th>NIP</th>
                            <th>NIDN</th>
                            <th>Nama</th>
                            <th>TanggalLahir</th>
                            <th>Jenis Kelamin</th>
                            <th>pendidikan terakhir</th>
                            <th>pangkat golongan</th>
                            <th>jabatan</th>
                        </tr>
                    </thead>
                    <tbody>
                ';

            include('koneksi.php');
            $kataKunci=$_POST['txtKataKunci'];
            //echo '<p>Hasil Pencarian data dengan kata kunci <b>'.$kataKunci.'</b></p>';

            $sqlCari=mysqli_query($hasilKoneksi, "SELECT * FROM dosen WHERE alamat LIKE '%$kataKunci%' or nama LIKE '%$kataKunci%' or no_wa LIKE '%$kataKunci%' or nis LIKE '%$kataKunci%'");
            $noUrut=null;
            while($hasilCari=mysqli_fetch_array($sqlCari,MYSQLI_ASSOC)){
                    $noUrut++;
                    $htmlTable .='
                    <tr>
                        <td align="center">'.$noUrut.'</td>
                        <td align="center">'.$hasilCari['nis'].'</td>
                        <td align="center">'.$hasilCari['nama'].'</td>
                        <td align="center">'.$hasilCari['alamat'].'</td>
                        <td align="center">'.$hasilCari['no_wa'].'</td>
                        <td align="center">'.'
                        <img src="FOTO/'.$hasilCari['foto'].'" width="70px">
                        </td>'.'</td>
                    </tr>';
                }
                $htmlTable .= '</tbody></table>
                ';
                $htmlTable.='<p class="text-dark" align="center">
                <b>Ditemukan  : '.mysqli_num_rows($sqlCari).' siswa</b>
            </p>
                ';
                echo $htmlTable;
            }

            

        ?>
</body>
</html>