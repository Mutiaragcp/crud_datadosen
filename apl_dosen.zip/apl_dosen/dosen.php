<?php
// membuat instance
$dataDosen=NEW Dosen;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<div class="container"><h3>Daftar Dosen</h3>';
$html .='<p>Berikut ini data dosen </p>';
$html .='<table class="table table-success table-striped" border="1" width="100%">
<thead>
<th>No.</th>
<th>NIP</th>
<th>NIDN</th>
<th>Nama</th>
<th>TanggalLahir</th>
<th>Jenis Kelamin</th>
<th>Pendidikan terakhir</th>
<th>pangkat golongan</th>
<th>jabatan struktural</th>
<th>aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $dataDosen->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisDosen){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisDosen->nip.'</td>
<td>'.$barisDosen->nidn.'</td=>
<td>'.$barisDosen->nama.'</td>
<td>'.$barisDosen->tanggal_lahir.'</td>
<td>'.$barisDosen->Jenis_Kelamin.'</td>
<td>'.$barisDosen->pendidikan_terakhir.'</td>
<td>'.$barisDosen->pangkat_golongan.'</td>
<td>'.$barisDosen->jabatan_struktural.'</td>
<td>
<a type="button" class="btn btn-outline-secondary"
href="index.php?file=dosen&aksi=edit&nip='.$barisDosen->nip.'">Edit</a>
<a type="button" class="btn btn-outline-secondary"
href="index.php?file=dosen&aksi=hapus&nip='.$barisDosen->nip.'">Hapus</a>
</td>
</tr>
</div>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST"action="index.php?file=dosen&aksi=simpan">';
$html .='<p>Nomor NIP<br/>';
$html .='<input type="text" name="txtNip"placeholder="Masukan NIP" autofocus/></p>';
$html .='<p>Nomor NIDN<br/>';
$html .='<input type="text" name="txtNidn"placeholder="Masukan NIDN" autofocus/></p>';
$html .='<p>Nama Lengkap<br/>';
$html .='<input type="text" name="txtNama"placeholder="Masukan Nama Lengkap" size="30" required/></p>';
$html .='<p>Tanggal Lahir<br/>';
$html .='<input type="date" name="txtTanggalLahir"required/></p>';
$html .='<p>Jenis Kelamin<br/>';
$html .='<input type="radio" name="txtJenisKelamin"value="Laki-laki"> Laki-laki';
$html .='<input type="radio" name="txtJenisKelamin"value="Perempuan"> Perempuan</p>';
$html .='<p>Pendidikan Terakhir<br/>';
$html .='<input type="text" name="txtPendidikanterakhir" placeholder="Masukan pendidikan terakhir" cols="50" rows="5" required></input></p>';
$html .='<p>Pangkat Golongan<br/>';
$html .='<input type="text" name="txtPangkatgolongan" placeholder="Masukan pangkat golongan" cols="50" rows="5" required></input></p>';
$html .='<p>Jabatan Struktural<br/>';
$html .='<input type="text" name="txtJabatanstruktural" placeholder="Masukan jabatan struktural" cols="50" rows="5" required></input></p>';
$html .='<p><input type="submit" name="tombolSimpan"value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'nip'=>$_POST['txtNip'],
'nidn'=>$_POST['txtNidn'],
'nama'=>$_POST['txtNama'],
'tanggal_lahir'=>$_POST['txtTanggalLahir'],
'jenis_Kelamin'=>$_POST['txtJenisKelamin'],
'pendidikan_terakhir'=>$_POST['txtPendidikanterakhir'],
'pangkat_golongan'=>$_POST['txtPangkatgolongan'],
'jabatan_struktural'=>$_POST['txtJabatanstruktural']
);
// simpan siswa dengan menjalankan method simpan
$dataDosen->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=dosen&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data guru
$dosen=$dataDosen->detail($_GET['nip']);
if($dosen->Jenis_Kelamin =='Laki-laki') { $pilihL='checked';
    $pilihP =null; }
    else {
    $pilihP='checked'; $pilihL =null; }
    $html =null;
    $html .='<h3>Form Tambah</h3>';
    $html .='<p>Silahkan masukan form </p>';
    $html .='<form method="POST"action="index.php?file=dosen&aksi=update">';
    $html .='<p>NIP<br/>';
    $html .='<input type="text" name="txtNip"value="'.$dosen->nip.'" placeholder="Masukan NIP"readonly/></p>';
    $html .='<p>NIDN<br/>';
    $html .='<input type="text" name="txtNidn"value="'.$dosen->nidn.'" placeholder="Masukan NIDN"size="30" required autofocus/></p>';
    $html .='<p>Nama Lengkap<br/>';
    $html .='<input type="text" name="txtNama"value="'.$dosen->nama.'" placeholder="Masukan Nama Lengkap"size="30" required autofocus/></p>';
    $html .='<p>Tempat Tanggal Lahir<br/>';
    $html .='<input type="date" name="txtTanggalLahir"value="'.$dosen->tanggal_lahir.'" required/></p>';
    $html .='<p>Jenis Kelamin<br/>';
    $html .='<input type="radio" name="txtJenisKelamin"value="Laki-laki" '.$pilihL.'> Laki-laki';
    $html .='<input type="radio" name="txtJenisKelamin"value="Perempuan" '.$pilihP.'> Perempuan</p>';
    $html .='<p>Pendidikan Terakhir<br/>';
    $html .='<input type="text" name="txtPendidikanterakhir"value="'.$dosen->pendidikan_terakhir.'" placeholder="Masukan Pendidikan Terakhir"size="30" required autofocus/></p>';
    $html .='<p>Pangkat Golongan<br/>';
    $html .='<input type="text" name="txtPangkatgolongan"value="'.$dosen->pangkat_golongan.'" placeholder="Masukan Pangkat Golongan"size="30" required autofocus/></p>';
    $html .='<p>Jabatan Struktural<br/>';
    $html .='<input type="text" name="txtJabatanstruktural"value="'.$dosen->jabatan_struktural.'" placeholder="Masukan Jabatan Struktural"size="30" required autofocus/></p>';
    $html .='<p><input type="submit" name="tombolSimpan"value="Simpan"/></p>';
    $html .='</form>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'nidn'=>$_POST['txtNidn'],
        'nama'=>$_POST['txtNama'],
'tanggal_lahir'=>$_POST['txtTanggalLahir'],
'jenis_Kelamin'=>$_POST['txtJenisKelamin'],
'pendidikan_terakhir'=>$_POST['txtPendidikanterakhir'],
'pangkat_golongan'=>$_POST['txtPangkatgolongan'],
'jabatan_struktural'=>$_POST['txtJabatanstruktural']);

$dataDosen->update($_POST['txtNip'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=dosen&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$dataDosen->hapus($_GET['nip']);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=dosen&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>